import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.JPanel;

public class DibujoElevadores extends JPanel {
   int ancho;
   int alto;
   int num_elevadores;
   ArrayList<Elevator> Lista;
   int c;

   public DibujoElevadores(int var1, int var2, int var3, ArrayList<Elevator> var4) {
      this.ancho = var1;
      this.alto = var2;
      this.num_elevadores = var3;
      this.Lista = var4;
   }

   // AGREGADO: Método para forzar actualización del dibujo
   public void actualizarElevadores() {
      this.repaint();
   }

   public void paintComponent(Graphics var1) {
      super.paintComponent(var1); // AGREGADO: Llamar al método padre
      this.c = 20;

      for(int var2 = 0; var2 < this.num_elevadores; ++var2) {
         // AGREGADO: Cambiar color según si el elevador está moviéndose
         Elevator elevator = this.Lista.get(var2);
         if (elevator.getDirection() != null) {
            var1.setColor(Color.ORANGE); // Color cuando está en movimiento
         } else {
            var1.setColor(Color.GRAY); // Color cuando está detenido
         }
         
         var1.fillRect(this.c, 200, this.ancho, this.alto);
         var1.setColor(Color.BLACK);
         var1.fillRect(this.c, 160, this.ancho, 35);
         var1.setColor(Color.WHITE);
         var1.setFont(new Font("Arial", 1, 18));
         String var3 = String.valueOf(elevator.getLevel());
         var1.drawString(var3, this.c + this.ancho / 2, 180);
         
         // AGREGADO: Mostrar dirección y cola de comandos
         var1.setColor(Color.BLUE);
         var1.setFont(new Font("Arial", 0, 12));
         String direccion = elevator.getDirection() == null ? "DETENIDO" : elevator.getDirection().toString();
         var1.drawString("Dir: " + direccion, this.c + 5, 220);
         var1.drawString("Cola: " + elevator.getListCopy().size(), this.c + 5, 240);
         
         this.c = this.c + this.ancho + 40;
      }
   }
}