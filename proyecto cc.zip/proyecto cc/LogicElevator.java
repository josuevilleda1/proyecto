import java.util.*;
import java.util.logging.*;
import java.io.IOException; 
// esta parte es la que dara la logic y las decicones del elevador 
public class LogicElevator {
    // obtiene una lista de cuantos elevadores tebemos dispoibles 
    private ArrayList<Elevator> elevadores;
    //es un arreglo de cuantas peticiones tenemos pedientes de trabajar
    private ArrayList<peticionusuario> solicitudes; 
    private int pisos;
    // devuleve  si el manager esta activo 
    private boolean trabajando;
    // nos guarda la informacion e cada accion que hace el manager 
    private Logger logger;
    // Thread para procesamiento continuo de solicitudes
    private Thread procesadores; 

//constructor de la logica del elevador 
    public LogicElevator(int pisos, ArrayList<Elevator> elevadores) {
        this.pisos = pisos;
        this.elevadores = elevadores;
        this.solicitudes = new ArrayList<>();
        this.trabajando = false;
        this.logger = Logger.getLogger("LogicElevator");
        
        try {
            FileHandler regisros = new FileHandler("LogsManager.log", true);
            regisros.setFormatter(new SimpleFormatter());
            logger.addHandler(regisros);
        } catch (IOException e) {
            System.err.println("Error creando archivo de log: " + e.getMessage());
            }
    }
// inicia el manager
    public void start() {
        this.trabajando = true;
        this.procesadores = new Thread(() -> {
            while (trabajando) {
                procesarSolicitudesPendientes();
                try {
                    Thread.sleep(100); 
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
        this.procesadores.start();
        logger.info("Elevator Manager iniciado");
    }

    private void procesarSolicitudesPendientes() {
        synchronized(solicitudes) {
            if (!solicitudes.isEmpty()) {
                peticionusuario solicitud = solicitudes.remove(0);
                Elevator mejorElevador = encontrarMejorElevador(solicitud);
                if (mejorElevador != null) {
                    mejorElevador.addCommand(solicitud.nivel);
                }
            }
        }
    }

// detiene el funcionamiento del manager 
    public void stop() {
        this.trabajando = false;
        if (this.procesadores != null) {
            this.procesadores.interrupt(); // 
        }
        logger.info("Elevator Manager detenido");
    } 
    //aqui agrega a la Arraylist la nueva solicutud del usuario para empezar a trabjar 

    public int peticion(int nivel, Direction direccion) {
        if (nivel < 1 || nivel > pisos) {
            logger.warning("Piso inválido: " + nivel);
            return -1;
        }
        
        peticionusuario solicitud = new peticionusuario(nivel, direccion);
        synchronized(solicitudes) {
            solicitudes.add(solicitud);
        }
        
        // También procesar inmediatamente por si acaso
        Elevator mejorElevador = encontrarMejorElevador(solicitud);
        if (mejorElevador != null) {
            mejorElevador.addCommand(nivel);
            logger.info("Solicitud del piso " + nivel + " " + direccion + " asignada al Elevador " + mejorElevador.getID());
            return mejorElevador.getID();
        } else {
            logger.warning("No hay elevador disponible para piso " + nivel);
            return -1;
        }
    }

// de los elevadores analizador por el metodod saturacionelevadores decide cual es el mejor para tomar las decision de que elevador asignar la tarea 
    public Elevator encontrarMejorElevador(peticionusuario solicitud){        
        Elevator mejorElevador = null; 
        int mejorPuntaje = Integer.MIN_VALUE; // 
        
        for (int i = 0; i < this.elevadores.size(); i++) {
            Elevator elevador = this.elevadores.get(i); 
            int puntajeActual = saturacionElevadores(elevador, solicitud);
            if (puntajeActual > mejorPuntaje) {
                mejorPuntaje = puntajeActual;
                mejorElevador = elevador;
            }
        }
        
        if (mejorElevador != null) {
            logger.info("Elevador " + mejorElevador.getID() + " recogera a la persona en el nivel " + solicitud.nivel);
        } else {
            logger.warning("No se encontró elevador adecuado para piso " + solicitud.nivel);
        }
        
        return mejorElevador;
    }

// entre todos los elevadores que hay decide analiza como estan sus estados comparandolos
// por medio de un sistema de punteo analiza cual es el mejor elevador 
// el metodo encontrarMejor elevador la manda allamar muchas veces para analizar 
//- direccion
//- si esta activo y como estan sus tareas
// se restan puntos dependeindo sus tareas y si va en otra direccion 

    public int saturacionElevadores(Elevator elevador, peticionusuario solicitud) {
        int puntuacion = 0;
        int pisoActual = elevador.getLevel();
        Direction DireccionDelElevador = elevador.getDirection();
        Direction dondeSeLLamo = solicitud.direccion;
        int pisoSolicitud = solicitud.nivel;
        if (DireccionDelElevador == dondeSeLLamo) {
            puntuacion += 100; 
            if (elevador.getLevel() < solicitud.nivel && DireccionDelElevador == Direction.UP){
                puntuacion += 50;
            } else if (elevador.getLevel() > solicitud.nivel && DireccionDelElevador == Direction.DOWN){
                puntuacion += 50;
            } else {
                puntuacion -= 30;
            }
        }  
        
        if (elevador.getListCopy().isEmpty()) {
            puntuacion += 200;
        }     
        if (DireccionDelElevador != dondeSeLLamo && DireccionDelElevador != null) {
            puntuacion -= 0; 
        }
        
        int tareasPendientes = elevador.getListCopy().size();
        puntuacion -= (tareasPendientes * 5); 
        
        return puntuacion;
    }

// hace que todos eleveadores queden en el nivel 1 y queden sin ninguna tarea 
    public void resetElevadores(){
        synchronized(solicitudes) {
            solicitudes.clear();
        }
        for (int i = 0; i < elevadores.size(); i++) {
            elevadores.get(i).reset();
        }
        logger.info("Sistema reiniciado - Todos los elevadores en piso 1");
    }

    // Este método es para cuando una persona DENTRO del elevador elige un piso destino
    public void destinoInterno(int idElevador, int nivelDestino) {
        for (int i = 0; i < elevadores.size(); i++) {
            Elevator elevador = elevadores.get(i);
            if (elevador.getID() == idElevador) {
                // Enviar el comando directamente al elevador
                elevador.addCommand(nivelDestino);
                logger.info("Destino interno: Elevador " + idElevador + " irá al piso " + nivelDestino);
                return;
            }
        }
        logger.warning("No se encontró el elevador con ID: " + idElevador);
    }
}