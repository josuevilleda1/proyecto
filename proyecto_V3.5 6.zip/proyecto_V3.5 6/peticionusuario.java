
public class peticionusuario{
    int nivel;
    Direction direccion;
    public peticionusuario (int nivel, Direction direccion ){
        this.nivel = nivel;
        this.direccion = direccion;
    }

    public String toString(){
        return "piso"+ nivel + direccion;
    }
}