public enum Direction {
    UP,
    DOWN
}