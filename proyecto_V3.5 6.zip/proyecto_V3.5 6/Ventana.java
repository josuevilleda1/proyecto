import javax.swing.*;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;

public class Ventana extends JFrame implements WindowConstants, RootPaneContainer {
    ArrayList<Elevator> Lista = new ArrayList<>();
    private JFrame Cuadro1;
    private JFrame Cuadro2;
    /* AHORA LA CREACION DE LS ELEVADORES ES ALGO PUBLICO QUE TODOS LOS METODOS MIRAMOS Y NOS SIRVE PARA PODER ASIGNAR COAS Y DAR UN MEJOR S
     * SEGUIMIENTO 
     */
    private DibujoElevadores d;
    int num_elevadores;
    int moveTime;
    int stopTime;
    int maxFloors;
    int nivel;
    int nivelADondeVoy;
    /*CAMBIE EL CONSTRUCTOR DE LA LOGICA DEL ELEVADOR PARA HACELRO MAS SENCIULLO 
     * LA LOGICA DEL MANAGER A NO USA TIEMPO ESO LO TRAE DE ELEAVTOR Y DE ESTA CLASE POR ESO QUITAMAMOS LOS DOS PARAMETROS PREVIOS 
     */
    LogicElevator l = new LogicElevator(1000, Lista);
    /*
    ACTUALIZA COSNTANTENMENTE LA INFORMACION DE LOS ELEVADORES ESO NOS SIRVE PARA SALTAROS ESA PARTE DE HACVERLO MANUAL
    Y ASI LOS METODOS LO HACEN SOLO POR MEDIO DE LOS THREADS
     */ 

    private Timer timerActualizacion;
    // VARIABLE PARA DARLE SEGUIMIENTO A LOS ELEVADORES
    private int ultimoElevadorAsignado = -1;
    private int pisoEsperandoElevador = -1;

    public Ventana() {
        crearCuadro1();
    }

    public final void crearCuadro1() {
        Cuadro1 = new JFrame("INICIO");

        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());

        JLabel etiqueta1 = new JLabel("Ingrese cantidad de elevadores: ");
        JTextField campo1 = new JTextField(20);

        JLabel etiqueta2 = new JLabel("Ingrese cantidad de pisos: ");
        JTextField campo2 = new JTextField(20);
        
        JLabel etiqueta3 = new JLabel("Ingrese tiempo entre pisos (en segundos): ");
        JTextField campo3 = new JTextField(20);

        JLabel etiqueta4 = new JLabel("Ingrese tiempo de espera (en segundos): ");
        JTextField campo4 = new JTextField(20);

        JButton iniciar = new JButton("Siguiente");
        iniciar.addActionListener((ActionEvent e) -> {
            Cuadro1.dispose();
            num_elevadores = Integer.parseInt(campo1.getText());
            maxFloors = Integer.parseInt(campo2.getText());
            moveTime = Integer.parseInt(campo3.getText())*1000;
            stopTime = Integer.parseInt(campo4.getText())*1000;
            crearCuadro2();
        });



        p.add(etiqueta1);
        p.add(campo1);
        p.add(etiqueta2);
        p.add(campo2);
        p.add(etiqueta3);
        p.add(campo3);
        p.add(etiqueta4);
        p.add(campo4);
        p.add(iniciar);

        Cuadro1.add(p);

        Cuadro1.setSize(300, 400);
        Cuadro1.setLocationRelativeTo(null);
        Cuadro1.setVisible(true);
    }

    public void crearCuadro2() {
        int AElevador = (1300 / num_elevadores) - 50;
        int HElevador = 400 - 50;
        Cuadro2 = new JFrame("Sistema de Elevadores");

        // AGREGADO: Configuración de parámetros del elevador
        Elevator.configure(moveTime,stopTime,maxFloors);

        for (int i = 0; i < num_elevadores; i++) {
            Elevator e = new Elevator();
            Lista.add(e);
            // INICIA LOS Elevadores 
            e.start();
        }

        // INICIA EL MANAGER
        l.start();

        // EL DIBUJO DE LOS ELEVADORES AHORA ES ALGO DE LA CLASE Y NO ES DE UN METODO EN ESPECIFCO ESO NOS SIRVE PARA EL ACCESO Y DAR LAS INSTRUCCIONES MAS RAPIOD
        d = new DibujoElevadores(AElevador, HElevador, num_elevadores, Lista);
        d.setLayout(new FlowLayout());

        /* Actualixa constamente a los elevadores para no tener problemas con la actualizacion  */
        timerActualizacion = new Timer(100, (ActionEvent e) -> {
            d.actualizarElevadores();
            Cuadro2.repaint();
            
            // AQUI DA SEGUIMIENTO A LOS ELEVADORES HAZTA VERIFICAR QUE LLEGO A S PISO DE DESTINO 
            if (ultimoElevadorAsignado != -1 && pisoEsperandoElevador != -1) {
                for (Elevator elevator : Lista) {
                    if (elevator.getID() == ultimoElevadorAsignado) {
                        if (elevator.getLevel() == pisoEsperandoElevador && elevator.getDirection() == null) {
                            int destino = ADondeVoy();
                            if (destino > 0) {
                                l.destinoInterno(ultimoElevadorAsignado, destino);
                            }
                            ultimoElevadorAsignado = -1;
                            pisoEsperandoElevador = -1;
                            break;
                        }
                    }
                }
            }
        });
        timerActualizacion.start();

        JButton arriba = new JButton("↑");
        arriba.setBounds((1300 / 2) - 60, 100, 50, 50);
        // SE MODIFICO COMO SE PIDE EL ELEAVDOR GUARDA E ID DEL ELEVADOR PARA DESPUES ASGINGARLO CUANDO LLEGUE AL PISO DE DESTINO
        arriba.addActionListener((ActionEvent e) -> {
            int pisoActual = CrearCuadroPisos();
            if (pisoActual > 0) {
                Direction dA = Direction.UP;
                int idElevador = l.peticion(pisoActual, dA);
                if (idElevador != -1) {
                    ultimoElevadorAsignado = idElevador;
                    pisoEsperandoElevador = pisoActual;
                    JOptionPane.showMessageDialog(Cuadro2, 
                        "Elevador " + idElevador + " viene por usted al piso " + pisoActual, 
                        "Elevador asignado", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        JButton abajo = new JButton("↓");
        abajo.setBounds((1300 / 2), 100, 50, 50);
        // SE MODIFICO COMO SE PIDE EL ELEAVDOR GUARDA E ID DEL ELEVADOR PARA DESPUES ASGINGARLO CUANDO LLEGUE AL PISO DE DESTINO

        abajo.addActionListener((ActionEvent e) -> {
            int pisoActual = CrearCuadroPisos();
            if (pisoActual > 0) {
                Direction dB = Direction.DOWN;
                int idElevador = l.peticion(pisoActual, dB);
                if (idElevador != -1) {
                    ultimoElevadorAsignado = idElevador;
                    pisoEsperandoElevador = pisoActual;
                    JOptionPane.showMessageDialog(Cuadro2, 
                        "Elevador " + idElevador + " viene por usted al piso " + pisoActual, 
                        "Elevador asignado", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        JButton reset = new JButton("Reset");
        reset.setBounds(600, 30, 100, 50);
        reset.addActionListener((ActionEvent e) -> {
            CrearReset();
        });

        JButton Pausar = new JButton("Pausar");
        Pausar.setBounds(200, 30, 100, 50);
        Pausar.addActionListener((ActionEvent e) -> {
            stopElevators();
        });

        JButton reanudar = new JButton("Reanudar");
        reanudar.setBounds(200, 100, 100, 50);
        reanudar.addActionListener((ActionEvent e) -> {
            reanudar();
        });

        JButton muerte = new JButton("Kill");
        muerte.setBounds(1000, 30, 100, 50);
        muerte.addActionListener((ActionEvent e) -> {
            int indice = Matar();
            Lista.remove(indice);
        });

        Cuadro2.add(muerte);
        Cuadro2.add(reanudar);
        Cuadro2.add(Pausar);
        Cuadro2.add(reset);
        Cuadro2.add(arriba);
        Cuadro2.add(abajo);
        Cuadro2.add(d);
        Cuadro2.pack();
        Cuadro2.setSize(1300, 600);
        Cuadro2.setLocationRelativeTo(null);
        Cuadro2.setVisible(true);

        Cuadro2.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
            for (int i = 0; i < num_elevadores; i++) {
                //Lista.get(i).cerrarLog();
                }

                System.exit(0);
        }});
    }

    public void reconfiguracion(){
        int r = JOptionPane.showConfirmDialog(null, "Desea modificar la configuración del sistema?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if(r == JOptionPane.YES_OPTION){Cuadro2.dispose(); crearCuadro1();}
    }

    public void CrearReset() {
        JFrame CuadroReset = new JFrame("Reset");

        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());

        JLabel instrucciones = new JLabel("¿Qué elevador quiere resetear?    ");
        p.add(instrucciones);
        int num = 1;
        for (int i = 0; i < num_elevadores; i++) {
            final int n = i;
            JButton elevadorx = new JButton("Elevador " + num);
            /*AQUI EL ELEVADOR USA EL timerActualizacion; PARA ACTALIZAR LA PINTURA DE LOS LEAVDORES */
            elevadorx.addActionListener((ActionEvent e) -> {
                Lista.get(n).reset();
                d.actualizarElevadores();
                Cuadro2.repaint();
                CuadroReset.dispose();
                reconfiguracion();
            });
            p.add(elevadorx);
            num = num + 1;
        }

        JButton Todos = new JButton("RESETEAR TODOS");
        // ACTUALIZAR EL LOS ELAVDORES DESPUES DE USAR EL BOTON DE RESET
        Todos.addActionListener((ActionEvent e) -> {
            l.resetElevadores();
            d.actualizarElevadores();
            Cuadro2.repaint();
            CuadroReset.dispose();
            reconfiguracion();
        });
        p.add(Todos);

        CuadroReset.add(p);
        CuadroReset.setSize(300, 300);
        CuadroReset.setLocationRelativeTo(null);
        CuadroReset.setVisible(true);
    }

    public int CrearCuadroPisos() {
        final JDialog Teclado = new JDialog((Frame) null, "TECLADO", true);
        AtomicReference<String> level = new AtomicReference<>("");
        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());

        JLabel inicio = new JLabel("Elija piso en el que se encuentra \n");
        p.add(inicio);

        for (int i = 1; i < maxFloors+1; i++) {
            final String n = String.valueOf(i);
            JButton piso_n = new JButton(n);
            p.add(piso_n);
            piso_n.addActionListener((ActionEvent e) -> {
                level.set(n);
                nivel = Integer.parseInt(level.get());
                Teclado.dispose();
            });
        }

        Teclado.setSize(240, 300);
        Teclado.setLocationRelativeTo(null);
        Teclado.add(p);
        Teclado.setVisible(true);
        return nivel;
    }

    /* POR NECESIDAD DE MI CLASE Y LO QUE MANDA A LLAMR PASAMOS ESTO DE VOID A UN INT  */
    public int ADondeVoy() {
        final JDialog Teclado = new JDialog((Frame) null, "DESTINO", true);
        AtomicReference<String> level = new AtomicReference<>("");
        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());
        JLabel inicio = new JLabel("Elija piso al que quiere ir \n");
        p.add(inicio);

        for (int i = 1; i < maxFloors+1; i++) {
            final String n = String.valueOf(i);
            JButton piso_n = new JButton(n);
            p.add(piso_n);
            piso_n.addActionListener((ActionEvent e) -> {
                level.set(n);
                nivelADondeVoy = Integer.parseInt(level.get());
                Teclado.dispose();
            });
        }

        JLabel etiqueta = new JLabel("                    OTRO");
        p.add(etiqueta);

        JTextField campo = new JTextField(18);
        p.add(campo);

        JButton otro = new JButton("Aceptar");
        p.add(otro);
        otro.addActionListener((ActionEvent e) -> {
            nivelADondeVoy = Integer.parseInt(campo.getText());
            Teclado.dispose();
        });

        Teclado.setSize(240, 300);
        Teclado.setLocationRelativeTo(null);
        Teclado.add(p);
        Teclado.setVisible(true);
        return nivelADondeVoy;
    }

    public static void main(String[] args) {
        new Ventana();
    }

    public void stopElevators() {
        JFrame CuadroReset = new JFrame("Reset");

        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());

        JLabel instrucciones = new JLabel("Presione el elevador a detener   ");
        p.add(instrucciones);
        int num = 1;
        for (int i = 0; i < num_elevadores; i++) {
            final int n = i;
            JButton elevadorx = new JButton("Elevador " + num);
            /*AQUI EL ELEVADOR USA EL timerActualizacion; PARA ACTALIZAR LA PINTURA DE LOS LEAVDORES */
            elevadorx.addActionListener((ActionEvent e) -> {
                Lista.get(n).stopExecution();
                d.actualizarElevadores();
                Cuadro2.repaint();
                CuadroReset.dispose();
            });
            p.add(elevadorx);
            num = num + 1;
        }

        CuadroReset.add(p);
        CuadroReset.setSize(300, 300);
        CuadroReset.setLocationRelativeTo(null);
        CuadroReset.setVisible(true);
    }
    public void reanudar() {
        JFrame CuadroReset = new JFrame("Reanudar");

        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());

        JLabel instrucciones = new JLabel("Presione el elevador a reanudar   ");
        p.add(instrucciones);
        int num = 1;
        for (int i = 0; i < num_elevadores; i++) {
            final int n = i;
            JButton elevadorx = new JButton("Elevador " + num);
            /*AQUI EL ELEVADOR USA EL timerActualizacion; PARA ACTALIZAR LA PINTURA DE LOS LEAVDORES */
            elevadorx.addActionListener((ActionEvent e) -> {
                Lista.get(n).resumeExecution();
                d.actualizarElevadores();
                Cuadro2.repaint();
                CuadroReset.dispose();
            });
            p.add(elevadorx);
            num = num + 1;
        }

        CuadroReset.add(p);
        CuadroReset.setSize(300, 300);
        CuadroReset.setLocationRelativeTo(null);
        CuadroReset.setVisible(true);
    }

    public int Matar() {
        JFrame Matar = new JFrame("Kill");

        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());

        JLabel instrucciones = new JLabel("Presione el elevador que desea que no funcione   ");
        p.add(instrucciones);
        int num = 1;
        for (int i = 0; i < num_elevadores; i++) {
            final int n = i;
            JButton elevadorx = new JButton("Elevador " + num);
            /*AQUI EL ELEVADOR USA EL timerActualizacion; PARA ACTALIZAR LA PINTURA DE LOS LEAVDORES */
            elevadorx.addActionListener((ActionEvent e) -> {
                Lista.get(n).kill();
                d.actualizarElevadores();
                Cuadro2.repaint();
                Matar.dispose();
            });
            p.add(elevadorx);
            num = num + 1;
        }
        Matar.add(p);
        Matar.setSize(300, 300);
        Matar.setLocationRelativeTo(null);
        Matar.setVisible(true);
        return num-1;
    }
}
